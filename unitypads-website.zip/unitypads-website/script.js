const header = document.querySelector(".site-header");
const menuButton = document.querySelector(".menu-toggle");
const navLinks = document.querySelector(".nav-links");
const cookieBanner = document.querySelector(".cookie-banner");
const cookieClose = document.querySelector(".cookie-close");
const year = document.querySelector("#year");

if (year) {
  year.textContent = new Date().getFullYear();
}

function updateHeader() {
  header.classList.toggle("scrolled", window.scrollY > 30);
}

updateHeader();
window.addEventListener("scroll", updateHeader, { passive: true });

menuButton?.addEventListener("click", () => {
  const isOpen = navLinks.classList.toggle("open");
  document.body.classList.toggle("menu-open", isOpen);
  menuButton.setAttribute("aria-expanded", String(isOpen));
});

document.querySelectorAll(".nav-links a").forEach((link) => {
  link.addEventListener("click", () => {
    navLinks.classList.remove("open");
    document.body.classList.remove("menu-open");
    menuButton?.setAttribute("aria-expanded", "false");
  });
});

const observer = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
        observer.unobserve(entry.target);
      }
    });
  },
  { threshold: 0.15 }
);

document.querySelectorAll(".reveal").forEach((element) => observer.observe(element));

const cookieDismissed = localStorage.getItem("unitypads-cookie-notice");

if (cookieDismissed === "closed") {
  cookieBanner?.remove();
}

cookieClose?.addEventListener("click", () => {
  localStorage.setItem("unitypads-cookie-notice", "closed");
  cookieBanner.remove();
});
