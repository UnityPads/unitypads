# Unity Pads website

A static, responsive website for Unity Pads Ltd.

## Files

- `index.html` — website content
- `style.css` — design and mobile responsiveness
- `script.js` — mobile menu, sticky header, reveal effects and cookie notice
- `images/logo.png` — Unity Pads logo
- `images/favicon.png` — browser icon

## Preview locally

Open `index.html` in a browser.

For a more accurate preview, install Visual Studio Code and the free **Live Server** extension, then right-click `index.html` and choose **Open with Live Server**.

## Publish free with Netlify

1. Create a free account at Netlify.
2. In Netlify, choose **Add new site → Deploy manually**.
3. Drag the entire `unitypads-website` folder into the upload area.
4. Netlify will give you a temporary web address.
5. Open **Domain management → Add a domain** and enter `unitypads.co.uk`.
6. Follow Netlify's DNS instructions in the company where you bought the domain.
7. Add `www.unitypads.co.uk` as a second domain and set the preferred version.

The contact form is already configured for Netlify Forms. After the first deployment, submit a test message. Enquiries will appear in Netlify under **Forms**. Configure email notifications in the Netlify dashboard.

## Important before publishing

- Replace the current Outlook email when your domain email is ready.
- Check the company name and legal details.
- Replace the stock photography with owned project photography when available.
- Add a privacy policy if you collect personal data through the contact form.
- Add your registered office and company registration number to the footer if appropriate.
